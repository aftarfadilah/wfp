<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

use Illuminate\Support\Str;

class TypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table('types')->insert([
            ['name' => 'Inn'],
            ['name' => 'Resort'],
            ['name' => 'Chain Hotel'],
            ['name' => 'Motel'],
            ['name' => 'All-suites'],
            ['name' => 'Conference/convention center hotel'],
            ['name' => 'Extended stay hotels'],
            ['name' => 'Boutique hotels'],
            ['name' => 'Bunkhouses'],
            ['name' => 'Bed and Breakfast'],
            ['name' => 'Eco hotels'],
            ['name' => 'Casino hotels'],
            ['name' => 'Pop-up hotels'],
            ['name' => 'Pet-friendly hotels'],
            ['name' => 'Roadhouses'],
            ['name' => 'Gastro hotels'],
            ['name' => 'Micro hotels'],
            ['name' => 'Transit hotels'],
            ['name' => 'Heritage hotels'],
            ['name' => 'Hostels'],
            ['name' => 'Unique concept hotels'],
        ]);
    }
}
