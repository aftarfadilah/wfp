<html>
    <body>
        <a href="<?php echo e(url('kategori')); ?>">Masuk dalam page Kategori</a><br>

        <a href="<?php echo e(url('promo')); ?>">Masuk dalam page Promo</a>

        <?php echo e($hotel); ?>

    </body>
</html><?php /**PATH C:\xampp\htdocs\my-apps\resources\views/hotel.blade.php ENDPATH**/ ?>