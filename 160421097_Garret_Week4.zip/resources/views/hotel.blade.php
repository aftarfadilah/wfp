<html>
    <body>
        <a href="{{ url('kategori') }}">Masuk dalam page Kategori</a><br>

        <a href="{{ url('promo') }}">Masuk dalam page Promo</a>

        {{$hotel}}
    </body>
</html>