<html>
    <body>
        <a href="{{ url('hotel') }}">Masuk dalam page Hotel</a><br>

        <a href="{{ url('kategori') }}">Masuk dalam page Kategori</a>

        {{$promo}}
    </body>
</html>