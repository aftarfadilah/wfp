<html>
    <body>
        <a href="<?php echo e(url('hotel')); ?>">Masuk dalam page Hotel</a><br>

        <a href="<?php echo e(url('kategori')); ?>">Masuk dalam page Kategori</a>

        <?php echo e($promo); ?>

    </body>
</html><?php /**PATH C:\xampp\htdocs\my-apps\resources\views/promo.blade.php ENDPATH**/ ?>