<html>
    <body>
        <a href="<?php echo e(url('hotel')); ?>">Masuk dalam page Hotel</a><br>

        <a href="<?php echo e(url('promo')); ?>">Masuk dalam page Promo</a><br>

        <?php echo e($kategori); ?>

    </body>
</html><?php /**PATH C:\xampp\htdocs\my-apps\resources\views/kategori.blade.php ENDPATH**/ ?>