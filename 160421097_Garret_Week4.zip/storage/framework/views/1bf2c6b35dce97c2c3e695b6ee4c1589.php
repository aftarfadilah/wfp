<html>
    <head><title></title></head>
    <table border='1'>
        <thead>
            <tr>
                <th>Nama</th>
                <th>Alamat</th>
                <th>Kota</th>
                <th>Tipe</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dataku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($hotel -> name); ?></td>
                <td><?php echo e($hotel -> address); ?></td>
                <td><?php echo e($hotel -> city); ?></td>
                <td><?php echo e($hotel -> type); ?></td>
            </tr>
                <?php if($hotel->products): ?>
                    <?php $__currentLoopData = $hotel -> products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td colspan="3"><?php echo e($product -> nama); ?></td>
                        <td><?php echo e($product -> price); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</html><?php /**PATH C:\xampp\htdocs\MyHotelBookingApps\MyHotelBookingApps\resources\views/hotel/index.blade.php ENDPATH**/ ?>